import React from 'react';

const TranTruongQuocBaoComp = () => {
    const name = "Tran Truong Quoc Bao";
    const program = "Computer Programming and Analysis";

    return (
        <div>
            <h1>{name}</h1>
            <p>{program}</p>
        </div>
    );
};

export default TranTruongQuocBaoComp;
