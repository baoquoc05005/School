import React from 'react';
import './App.css';
import TranTruongQuocBaoComp from './TranTruongQuocBaoComp';

function App() {
    return (
        <div className="App">
            <header className="App-header">
                <TranTruongQuocBaoComp />
            </header>
        </div>
    );
}

export default App;
