import React from 'react';

const Account = () => (
  <main className="container my-5">
    <div className="row">
      <div className="col-md-12">
        <h1>Account Management</h1>
        <p>This is where users will manage their account details.</p>
      </div>
    </div>
  </main>
);

export default Account;
