import React from 'react';

const SearchResults = () => (
  <main className="container my-5">
    <div className="row">
      <div className="col-md-12">
        <h1>Search Results</h1>
        <p>This is where search results will be displayed.</p>
      </div>
    </div>
  </main>
);

export default SearchResults;
