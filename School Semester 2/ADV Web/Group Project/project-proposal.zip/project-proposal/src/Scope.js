import React from 'react';

const Scope = () => (
  <section className="container my-4">
    <h2>Scope of the Project</h2>
    <p>For the group project, I’m planning to build a web application that will discover and track popular movies and TV shows. By using data from Robust API, I’ll create an app platform for movie enthusiasts.</p>
  </section>
);

export default Scope;
