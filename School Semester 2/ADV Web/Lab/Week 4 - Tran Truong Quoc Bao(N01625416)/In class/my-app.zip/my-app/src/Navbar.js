import React from 'react';
import './App.css';

function Navbar() {
  return (
    <nav className="navbar">
      <h1>Navbar</h1>
    </nav>
  );
}

export default Navbar;
