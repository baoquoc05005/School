import React from 'react';
import './App.css';

function MainContent() {
  return (
    <main className="mainContent">
      <h1>Main Content</h1>
    </main>
  );
}

export default MainContent;
