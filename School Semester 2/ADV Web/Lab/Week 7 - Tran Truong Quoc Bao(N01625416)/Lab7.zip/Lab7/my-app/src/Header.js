import React from 'react';
import './styles.css';  // Import the styles

function Header() {
  return (
    <div className="header">
      <h1>Tran Truong Quoc Bao</h1>
      <p>Student Number: N01625416</p>
    </div>
  );
}

export default Header;
