import React from 'react';
import styles from './Home.module.css';

const Home = () => {
    return <h2 className={styles.home}>Home Page</h2>;
}

export default Home;
