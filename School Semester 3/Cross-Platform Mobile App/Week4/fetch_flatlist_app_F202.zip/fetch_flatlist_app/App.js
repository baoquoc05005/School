import { useEffect, useState } from 'react';
import { StyleSheet, 
  Text, 
  View,
  FlatList,
  ActivityIndicator,
  Pressable,
  Alert,
  StatusBar,
  Button,
  Platform
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import { Picker } from '@react-native-picker/picker';

// npm install @react-native-picker/picker

export default function App() {

  //values for barStyle property of StatusBar
  const STYLES = ['default', 'dark-content', 'light-content'];

  //values for backgroundColor property of StatusBar
  //only Android allows to change the backgroundColor of StatusBar
  const COLORS = ['#61dafb', '#ff6347', '#32cd32', '#000000', '#ffffff'];

  //values for transition property of StatusBar
  const TRANSITIONS = ['fade', 'slide', 'none'];

  const [hidden, setHidden] = useState(false)
  const [statusBarStyle, setStatusBarStyle] = useState(STYLES[0])
  const [statusBarColor, setStatusBarColor] = useState(COLORS[0])
  const [statusBarTransition, setStatusBarTransition] = useState(TRANSITIONS[0])

  //array to store movies data
  const [data, setData] = useState([])
  const [isLoading, setIsLoading] = useState(false)

  //function to retrieve movies data from API
  const getMoviesFromApi = async() => {

    setIsLoading(true)//indicates data is loading

    const url = 'https://reactnative.dev/movies.json'

    try{
      const response = await fetch(url);

      if (!response.ok){
        //unsuccessful response
        throw new Error(`Response Status : ${response.status}. 
          Response not received successfully from API.`)
      }

      //successful response
      //attempt to access JSON data from response
      const jsonData = await response.json()

      setData(jsonData.movies)

      console.log(`Response received from web servvice : 
        ${JSON.stringify(jsonData.movies)}`);
      
      return jsonData.movies;

    }catch(err){
      console.log(`Error while fetching the data from API : ${err}`);
    }finally{
      //stop loading data to show error or retrieved data
      setIsLoading(false)
    }
  }

  //every time component is created, fetch the movies data from API
  useEffect( () => {
    getMoviesFromApi()
  }, [])

  const onListItemPressed = (item) =>{
    Alert.alert(`You selected ${item.title}`)
  }

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.safeArea}>

        <StatusBar
        barStyle={statusBarStyle}
        backgroundColor={statusBarColor}
        showHideTransition={statusBarTransition}
        hidden={hidden}
        animated={true}
        />

        <View style={styles.container}>
          <Text>FlatList, FetchAPI, StatusBar, Picker</Text>

          { isLoading ? 
          (
            <ActivityIndicator />
          ) : 
          ( 
            <FlatList 
              data={data}
              keyExtractor={ ( {id} ) => id.toString() }
              renderItem={ ( {item} ) => (

                <Pressable
                  style={styles.itemContainer}
                  onPress = { ()=> {onListItemPressed(item)} }
                >
                  <Text style = {styles.itemText}>{item.title} - {item.releaseYear}</Text>
                </Pressable>

              ) }//renderItem

              ItemSeparatorComponent={ () => {
                return <View style={styles.separator} />
              }}

            />
          )}
        </View>

        <View style={styles.container}>

          <Button title='Toggle Status Bar' onPress={() => {setHidden(!hidden)}} />

          <View style={styles.horizontalContainer}>
            <Text style={styles.label}>Bar Style : </Text>
            <Picker
              selectedValue={statusBarStyle}
              onValueChange={ (itemValue) => setStatusBarStyle(itemValue) }
              style = {styles.picker}
            >
              {
                STYLES.map( (element) => (
                  <Picker.Item label={element} value={element} key={element} />
                ))
              }
            </Picker>
          </View>//horizontalContainer

          { Platform.OS === 'android' && 
            <View style={styles.horizontalContainer}>
              <Text style={styles.label}>Status Bar Color : </Text>
              <Picker
                selectedValue={statusBarColor}
                onValueChange={ (itemValue) => setStatusBarColor(itemValue) }
                style = {styles.picker}
              >
                {
                  COLORS.map( (element) => (
                    <Picker.Item label={element} value={element} key={element} />
                  ))
                }
              </Picker>
            </View>
          }

          { Platform.OS === 'ios' &&
            <View style={styles.horizontalContainer}>
              <Text style={styles.label}>Status Bar Transition : </Text>
              <Picker
                selectedValue={statusBarTransition}
                onValueChange={ (itemValue) => setStatusBarTransition(itemValue) }
                style = {styles.picker}
              >
                {
                  TRANSITIONS.map( (element) => (
                    <Picker.Item label={element} value={element} key={element} />
                  ))
                }
              </Picker>
            </View>
          }

          {/* <Text>statusBarStyle : {statusBarStyle}</Text>
          <Text>statusBarColor : {statusBarColor}</Text>
          <Text>statusBarTransition : {statusBarTransition}</Text> */}

        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'flex-start',
    width: '100%'
  },
  safeArea: {
    flex: 1,
    backgroundColor: '#fff',
    width: '100%'
  },
  itemContainer: {
    width: '100%',
    padding: '1%',
    backgroundColor: 'cyan',
    borderRadius: 5,
    marginVertical: 3,
    marginHorizontal: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
  },
  itemText: {
    fontSize: 18,
    color: '#333',
  }, 
  separator: {
    height: 3,
    marginVertical: 2,
    backgroundColor: 'gray'
  },
  picker:{
    flex: 1,
    height: 10
  },
  horizontalContainer:{
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginVertical: 10,
  },
  label: {
    fontSize: 20,
    marginRight: 10
  }
});
