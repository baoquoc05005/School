import { useEffect, useState } from 'react';
import { StyleSheet, 
  Text, 
  View
} from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

// npm install @react-native-picker/picker

export default function App() {

  //values for barStyle property of StatusBar
  const STYLES = ['default', 'dark-content', 'light-content'];

  //values for backgroundColor property of StatusBar
  //only Android allows to change the backgroundColor of StatusBar
  const COLORS = ['#61dafb', '#ff6347', '#32cd32', '#000000', '#ffffff'];

  //values for transition property of StatusBar
  const TRANSITIONS = ['fade', 'slide', 'none'];

  const [hidden, setHidden] = useState(false)
  const [statusBarStyle, setStatusBarStyle] = useState(STYLES[0])
  const [statusBarColor, setStatusBarColor] = useState(COLORS[0])
  const [statusBarTransition, setStatusBarTransition] = useState(TRANSITIONS[0])

  //array to store movies data
  const [data, setData] = useState([])

  //function to retrieve movies data from API
  const getMoviesFromApi = async() => {

    const url = 'https://reactnative.dev/movies.json'

    try{
      const response = await fetch(url);

      if (!response.ok){
        //unsuccessful response
        throw new Error(`Response Status : ${response.status}. 
          Response not received successfully from API.`)
      }

      //successful response
      //attempt to access JSON data from response
      const jsonData = await response.json()

      setData(jsonData.movies)

      console.log(`Response received from web servvice : 
        ${JSON.stringify(jsonData.movies)}`);
      
      return jsonData.movies;

    }catch(err){
      console.log(`Error while fetching the data from API : ${err}`);
    } 
  }

  //every time component is created, fetch the movies data from API
  useEffect( () => {
    getMoviesFromApi()
  }, [])

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.container}>
          <Text>FlatList, FetchAPI, StatusBar, Picker</Text>
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  safeArea: {
    flex: 1,
    backgroundColor: '#fff'
  },
  itemContainer: {
    padding: 10,
    backgroundColor: 'cyan',
    borderRadius: 5,
    marginVertical: 10,
    marginHorizontal: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
  },
  itemText: {
    fontSize: 18,
    color: '#333',
  }, 
});
