import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, Button, Alert, TextInput } from 'react-native';
import { useState } from 'react';

export default function App() {

  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [age, setAge] = useState(0)

   const showAlert = () => {
    Alert.alert("Button Pressed", "Alright !")
  }

  return (
    <View style={styles.container}>
      <Text>Week 2 - Components App</Text>
      <Text>Winter 2025</Text>

      <Image 
        style = {styles.imgStyle}
        source={
          {uri: "https://images.freeimages.com/images/large-previews/9f7/sleeping-cat-1359219.jpg" }
        }
      />

      <Button
        title='Press Me !'
        onPress={showAlert}
      />

      <TextInput 
        style={styles.input}
        value={name}
        onChangeText={setName}
        placeholder='Enter your name'
        keyboardType='default'
        autoCapitalize='words'
        autoCorrect={true}
        maxLength={100}
      />

      <TextInput 
        style={styles.input}
        value={email}
        onChangeText={setEmail}
        placeholder='Enter your email address'
        keyboardType='email-address'
        autoCapitalize='none'
        autoCorrect={false}
        autoComplete='email'
      />

      <TextInput 
        style={styles.input}
        value={password}
        onChangeText={setPassword}
        placeholder='Enter your password'
        autoCapitalize='none'
        autoCorrect={false}
        secureTextEntry={true}
        maxLength={10}
      />

      <TextInput 
        style={styles.input}
        value={age}
        onChangeText={setAge}
        placeholder='Enter your age'
        keyboardType='numeric'
      />

{/* Add more Text components to show all the inputs received from user */}
      <Text>Output</Text>
      <Text>Name : {name}</Text>

      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  imgStyle : {
    width: 300,
    height: 200
  },
  input : {
    height: 40,
    padding: 5,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: 'blue'
  },
});


