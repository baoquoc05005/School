import { StyleSheet, View, Text, TouchableOpacity } from "react-native"
import globalStyles from "../shared/GlobalStyles";
import { useNavigation } from "@react-navigation/native";

const ContactScreen = () => {
    const navigation = useNavigation();

    return(
        <View style={globalStyles.container}>
            <Text style={globalStyles.headerStyle}>Contact Screen</Text>

            <Text style={globalStyles.title}>Country :</Text>
            <Text style={globalStyles.title}>City : </Text>

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                    //navigate to About Screen
                    navigation.navigate("About")
                }}
            >
                <Text style = {globalStyles.buttonText}>About</Text>
            </TouchableOpacity>

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                    //navigate to Home screen ; also supply username route parameter
                }}
            >
                <Text style = {globalStyles.buttonText}>Home</Text>
            </TouchableOpacity> 

            <TouchableOpacity
                style = {globalStyles.button}
                onPress={() => {
                     //navigate to Previous screen
                }}
            >
                <Text style = {globalStyles.buttonText}>Go Back</Text>
            </TouchableOpacity> 
        </View>
    )
}

export default ContactScreen;
