//TabNavigationScreen
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import ProfileScreen from "./ProfileScreen";
import SettingsScreen from "./SettingsScreen";
import Icon from "react-native-vector-icons/FontAwesome";

// import { NavigationContainer } from "@react-navigation/native";

const Tab = createBottomTabNavigator();

export default TabNavigationScreen = ({navigation, route}) => {

    const tabOptions = ({route}) => ( {
        tabBarActiveTintColor: 'indigo',
        tabBarInactiveTintColor: 'gray',
        tabBarStyle: [ {display: 'flex'} ],
        tabBarIcon: ( {focused} ) => {
            let iconName;

            if (route.name === "Profile"){
                iconName = focused ? 'user' : 'user-o'
            }else if (route.name === "Settings"){
                iconName = 'cog'
            }

            return (
                <Icon name={iconName} color='indigo' size={30} />
            )
        }
    } )

    return(
        // You need to put Tab.Navigator within NavigationContainer 
        // if your app begins navigation with Tabs
        // similar to what we have in App.js in this application

        // <NavigationContainer>
        <Tab.Navigator screenOptions={tabOptions}>
            <Tab.Screen component={ProfileScreen} name="Profile" />
            <Tab.Screen component={SettingsScreen} name="Settings" />
        </Tab.Navigator>
        // </NavigationContainer> 
    )
}