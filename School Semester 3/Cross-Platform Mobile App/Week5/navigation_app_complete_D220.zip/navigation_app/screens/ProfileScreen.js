import { StyleSheet, View, Text } from "react-native";
import globalStyles from "../shared/GlobalStyles";

const ProfileScreen = () => {
    return(
        <View style={globalStyles.container}>
            <Text style={globalStyles.headerStyle}>Profile Screen</Text>
        </View>
    )
}

export default ProfileScreen
