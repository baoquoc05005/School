//TabNavComponent.js
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
// import { NavigationContainer } from "@react-navigation/native";
import Icon from "react-native-vector-icons/FontAwesome";
import ProfileScreen from "./ProfileScreen";
import SettingsScreen from "./SettingsScreen";


const Tab = createBottomTabNavigator()

export default TabNavComponent = () => {

    const tabOptions = ({route}) => ({
        tabBarActiveTintColor: 'indigo',
        tabBarInactiveTintColor: 'gray',
        tabBarStyle: [ {display : 'flex'}],
        tabBarIcon: ( {focused} ) => {
            let iconName
            let colorName

            if (route.name === "Profile"){
                iconName = focused ? 'user' : 'user-o'
            }else if (route.name === "Settings"){
                iconName = 'cog'
            }

            colorName = focused ? 'indigo' : 'gray'

            return (
                <Icon name={iconName} color={colorName} size={25} />
            )
        }
    })

    return(
        // <NavigationContainer>
        <Tab.Navigator screenOptions={tabOptions}>
            <Tab.Screen component={ProfileScreen} name="Profile" />
            <Tab.Screen component={SettingsScreen} name="Settings" />
        </Tab.Navigator>
        // </NavigationContainer>
    )
}