import { StyleSheet, View, Text } from "react-native";
import globalStyles from "../shared/GlobalStyles";

const SettingsScreen = () => {
    return(
        <View style={globalStyles.container}>
            <Text style={globalStyles.headerStyle}>Settings Screen</Text>
        </View>
    )
}

export default SettingsScreen
