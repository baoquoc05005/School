import { Button, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';
import globalStyles from "./shared/GlobalStyles";

import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { CommonActions, NavigationContainer } from '@react-navigation/native';

import HomeScreen from './screens/HomeScreen';
import AboutScreen from './screens/AboutScreen';
import ContactScreen from './screens/ContactScreen';
import TabNavComponent from './screens/TabNavComponent';

//get an instance of Stack Navigator
const Stack = createNativeStackNavigator();

/*

to use React Navigation library
npm install @react-navigation/native

to use expo project with ReactNavigation
npm install react-native-screens react-native-safe-area-context

for Stack navigation
npm install @react-navigation/native-stack

for bottom tab navigation
npm install @react-navigation/bottom-tabs

for icons
npm install --save react-native-vector-icons

*/

export default function App() {

  const headerOptions = ({navigation}) => ({
    headerStyle: {
      backgroundColor: 'indigo'
    },
    headerTintColor: 'white',
    headerTitleAlign: 'center',
    headerTitleStyle: { fontWeight: 'bold'},
    headerRight: () => (
      <TouchableOpacity
        onPress={() => {
          navigation.dispatch(CommonActions.reset({
            index: 0,
            routes: [{name: "Home"}] //routes: [{name: "Login"}]
          }))
        }}
      >
        <Text style={ {color: 'white'} }>Logout</Text>
      </TouchableOpacity>
    )
  })

  return (
    <SafeAreaProvider>
    <SafeAreaView style={globalStyles.safeArea}>

      <NavigationContainer>
        <Stack.Navigator initialRouteName='Home'>

          <Stack.Group screenOptions={headerOptions}>

            {/* <Stack.Screen component={AboutScreen} name="About" options={headerOptions}/> */}
            <Stack.Screen component={AboutScreen} name="About"/>
            
            <Stack.Screen 
              component={HomeScreen} 
              name="Home"
              initialParams={ {username: "NA"} }
            />

            <Stack.Screen 
              component={ContactScreen} 
              name="Contact" 
              initialParams={ {country: "NA", city: "NA"} }
              // initialParams is used to set default values for expected route params
              // will be used in absence of route params
            />

            <Stack.Screen component={TabNavComponent} name="TabNav" />

          </Stack.Group>
        </Stack.Navigator>
      </NavigationContainer>
    
    </SafeAreaView>
    </SafeAreaProvider>
  );
}

{/* <View style={globalStyles.container}>
      <HomeScreen />
    </View> */}
    {/* <View style={globalStyles.spacer} /> */}
