import { StyleSheet } from "react-native";
import { SIZES, COLORS } from "./Constants";

const globalStyles = StyleSheet.create({
    safeArea:{
        flex: 1
    },
    container:{
        flex: 1,
        backgroundColor: COLORS.primary,
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    headerStyle: {
        width: '100%',
        padding: SIZES.padding,
        color: COLORS.text,
        backgroundColor: COLORS.background,
        fontSize: SIZES.titleSize,
        fontWeight: 'bold',
        textAlign: 'center'
      },
    board: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        // borderWidth: 5,
        // borderColor: 'black',
        width: '90%',
        height: '40%',
        justifyContent:'space-between',
        padding: SIZES.padding
    },
    cell: {
        width: '31%',
        height: '31%',
        backgroundColor: COLORS.secondary,
        marginVertical: SIZES.margin,
        justifyContent: 'center',
        alignItems: 'center'
    },
    cellText: {

    },
    scoreBoard: {
        backgroundColor: COLORS.background,
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: SIZES.padding,
        margin: SIZES.margin,
        marginVertical: '5%'
    },
    textStyle: {
        fontSize: SIZES.subTitleSize,
        fontWeight: 'bold'
    },
    button:{
        padding: '2%',
        borderRadius: 10,
        justifyContent: 'center',
        alignItems: 'center',
        width: '90%',
        backgroundColor: 'indigo',
    }
})

export default globalStyles