export const COLORS = {
    primary: 'ivory',
    secondary: 'darkorchid',
    background: 'greenyellow',
    text: 'indigo'
}

export const SIZES = {
    padding : '1%',
    margin: '1%',
    titleSize: 40,
    subTitleSize: 30
}