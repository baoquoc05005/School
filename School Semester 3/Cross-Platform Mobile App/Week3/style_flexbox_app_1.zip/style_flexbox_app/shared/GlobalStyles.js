import { StyleSheet } from "react-native";

const globalStyles = StyleSheet.create({
    container:{
        flex: 1,
        backgroundColor: "#fff",
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    headerStyle: {
        width: '100%',
        padding: 10,
        color: 'maroon',
        // backgroundColor: 'cyan',
        fontSize: 30,
        fontWeight: 'bold',
        textAlign: 'center'
      },
    board: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        // backgroundColor: 'yellow',
        // borderWidth: 5,
        // borderColor: 'black',
        width: '90%',
        height: '40%',
        justifyContent:'space-between',
        padding: '1%'
    },
    cell: {
        width: '31%',
        height: '31%',
        backgroundColor: 'plum',
        marginVertical: '1%'
    },
    cellText: {

    },
    scoreBoard: {
        backgroundColor: 'cyan',
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: '2%',
        margin: '1%',
        marginVertical: '5%'
    },
    textStyle: {
        fontSize: 36,
        fontWeight: 'bold'
    }
})

export default globalStyles