import { StyleSheet, Text, View } from "react-native";
import globalStyles from "../shared/GlobalStyles";

const HomeScreen = () => {
    return(
        <View style={globalStyles.container}>
            <Text style={ [
                globalStyles.headerStyle, 
                styles.title, 
                {color: 'red'} 
                ]}>Home Screen</Text>
        </View>
    )
}

export default HomeScreen

const styles = StyleSheet.create({
    title: {
        fontStyle: 'italic',
        color: 'magenta'
    }
})