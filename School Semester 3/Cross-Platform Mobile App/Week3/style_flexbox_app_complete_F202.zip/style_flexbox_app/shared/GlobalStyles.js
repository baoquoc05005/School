import { StyleSheet } from "react-native";
import { SIZES, COLORS } from "./Constants";

const globalStyles = StyleSheet.create({
    safeArea: {
        flex: 1
    },
    container:{
        flex: 1,
        backgroundColor: "#fff",
        justifyContent: 'flex-start',
        alignItems: 'center'
    },
    headerStyle: {
        width: '100%',
        padding: SIZES.padding,
        color: COLORS.secondary,
        backgroundColor: COLORS.primary,
        fontSize: SIZES.titleSize,
        fontWeight: 'bold',
        textAlign: 'center'
      },
    board: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        // backgroundColor: 'yellow',
        // borderWidth: 5,
        // borderColor: 'black',
        width: '90%',
        height: '40%',
        justifyContent:'space-between',
        padding: SIZES.padding
    },
    cell: {
        width: '31%',
        height: '31%',
        backgroundColor: COLORS.background,
        marginVertical: SIZES.margin,
        alignItems: 'center',
        justifyContent: 'center'
    },
    cellText: {
        fontSize: SIZES.titleSize,
        fontWeight: 'bold',
        color: 'indigo'
    },
    button:{
        padding: '2%',
        borderRadius: 8,
        alignItems: 'center',
        justifyContent: 'center',
        width: '100%',
        backgroundColor: COLORS.background
    },
    scoreBoard: {
        backgroundColor: 'cyan',
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        padding: '2%',
        margin: '1%',
        marginVertical: '5%'
    },
    textStyle: {
        fontSize: 36,
        fontWeight: 'bold'
    }
})

export default globalStyles