export const COLORS = {
    primary : 'dodgerblue',
    secondary : 'darksalmon',
    background : 'greenyellow',
    text : 'black'
}

export const SIZES = {
    padding : '1%',
    margin: '1%',
    titleSize : 40,
    subTitleSize : 30
}