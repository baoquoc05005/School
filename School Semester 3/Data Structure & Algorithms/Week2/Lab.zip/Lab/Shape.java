
//I Define Shape interface to handle different shapes using getColor() and getArea()
public interface Shape {
    String getColor();
    double getArea();
}
