// Interface  defines the method to get participating hours based on course hours
public interface ParticipateHours {
    int getParticipatingHours(int courseHours);
}

//Name: Tran Truong Quoc Bao
//StudentID: N01625416